# DIA-2026-001: Clinical Trial Database (SQL & Data Management Portfolio)

A simulated Phase II clinical trial database built to practise and demonstrate **Clinical Data Management (CDM)** skills: SQL-based data review, edit checks, query management and SAE reconciliation, as done at a CRO.

> **All data is synthetic.** No real patient information is used.

**Tools:** MySQL 8.0, SQL, Excel | **Standards:** tables mapped to CDISC SDTM domains (DM, AE, LB, VS, CM)

## What this project shows

| Skill | Where |
|---|---|
| Database design (PK/FK, CHECK constraints, indexes) with 6 core tables mirroring SDTM | `sql/01_schema.sql` |
| JOINs, CTEs, subqueries, views | `sql/04_joins_ctes.sql` |
| Window functions (`RANK`, `DENSE_RANK`, `ROW_NUMBER`, `LAG`, `FIRST_VALUE`, `PARTITION BY`) | `sql/05_window_functions.sql` |
| Edit checks: out-of-range labs, duplicates, missing data, date logic | `sql/06_data_quality_checks.sql` |
| Query Log lifecycle (raised, answered, resolved, closed) and metrics | `sql/07_query_log_workflow.sql` |
| SAE reconciliation (EDC vs safety database) | `sql/08_sae_reconciliation.sql`, `docs/sae_reconciliation.md` |
| Data Management Plan | `docs/data_management_plan.md` |

## Repository structure

```
DIA-2026-001-clinical-trial-database/
├── README.md
├── data/                      CSV files + one Excel workbook (DIA-2026-001_dataset.xlsx)
├── sql/
│   ├── 01_schema.sql          create database + tables
│   ├── 02_sample_data.sql     synthetic data (20 subjects, 2 sites)
│   ├── 03_basic_queries.sql   Tasks 1-10
│   ├── 04_joins_ctes.sql      Tasks 11-18
│   ├── 05_window_functions.sql Tasks 19-26
│   ├── 06_data_quality_checks.sql  DQ-01 to DQ-15
│   ├── 07_query_log_workflow.sql   Tasks 27-33
│   └── 08_sae_reconciliation.sql   Tasks 34-35
├── docs/
│   ├── data_management_plan.md
│   ├── data_dictionary.md
│   ├── query_log_process.md
│   └── sae_reconciliation.md
└── tasks/
    └── SQL_TASKS.md           all 35 tasks with expected results
```

## How to run

```bash
mysql -u root -p < sql/01_schema.sql
mysql -u root -p < sql/02_sample_data.sql
mysql -u root -p dia_2026_001 < sql/03_basic_queries.sql
```
Or open the files in MySQL Workbench and run them in order.

## Study snapshot

- 20 subjects, 2 sites (101, 102), 2 arms (Placebo, Drug A 10mg), 12-week treatment
- 25 adverse events (4 serious), ~376 lab results, 300 vital sign records
- Deliberately seeded data problems for the edit checks to find: duplicate lab record, missing values, AE dates out of sequence, out-of-range labs and vitals, missing causality, and SAE discrepancies between EDC and the safety database

## Seeded issues and the check that finds them

| Issue | Check |
|---|---|
| Duplicate ALT record (Subj 101-001, Week 8) | DQ-01 |
| Missing lab / vital values | DQ-02, DQ-03 |
| 8 out-of-range labs (ALT, AST, creatinine, Hgb, glucose) | DQ-05 |
| SBP 182, pulse 122 | DQ-06 |
| AE starts before first dose | DQ-07 |
| AE end date before start date | DQ-08 |
| AE missing causality | DQ-09 |
| Con-med missing indication | DQ-11 |
| Missing age | DQ-13 |
| SAE mismatches (date, causality, missing in either system) | Task 34 |

## Author

Bathina Deepak | B.Pharm | Aspiring Clinical Data Associate
