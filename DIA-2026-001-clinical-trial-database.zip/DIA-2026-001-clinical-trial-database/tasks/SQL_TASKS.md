# SQL Tasks

35 practice tasks plus 15 data-quality checks. Each row gives the file holding the solution query and the number of rows it returns on the provided sample data, so you can self-check your own answer.

| # | Task | File | Expected rows |
|---|---|---|---|
| Task 1 | Enrolment by arm and site | `03_basic_queries.sql` | 4 |
| Task 2 | Age summary by arm (NULL ages ignored by aggregates) | `03_basic_queries.sql` | 2 |
| Task 3 | Subjects with missing age | `03_basic_queries.sql` | 1 |
| Task 4 | Early discontinuations (< 84 days on study) | `03_basic_queries.sql` | 2 |
| Task 5 | AE count per subject, only subjects with 2+ AEs (HAVING) | `03_basic_queries.sql` | 8 |
| Task 6 | AE severity distribution | `03_basic_queries.sql` | 3 |
| Task 7 | All serious AEs (SAEs) | `03_basic_queries.sql` | 4 |
| Task 8 | Classify lab results with CASE WHEN | `03_basic_queries.sql` | 376 |
| Task 9 | Lab flag summary per test | `03_basic_queries.sql` | 5 |
| Task 10 | UNION - subjects who had an SAE OR a lab value above 2x ULN | `03_basic_queries.sql` | 6 |
| Task 11 | AEs with subject demographics (INNER JOIN) | `04_joins_ctes.sql` | 25 |
| Task 12 | Subjects with NO adverse events (LEFT JOIN / anti-join) | `04_joins_ctes.sql` | 5 |
| Task 13 | AE incidence by arm (subjects with >=1 AE / subjects in arm) | `04_joins_ctes.sql` | 2 |
| Task 14 | Out-of-range labs with subject context | `04_joins_ctes.sql` | 8 |
| Task 15 | Subquery - subjects whose max ALT is above the study average ALT | `04_joins_ctes.sql` | 17 |
| Task 16 | Con-med taken for an AE (indication matches AE term) - self join logic | `04_joins_ctes.sql` | 3 |
| Task 17 | CTE - first-dose-relative study day of each AE | `04_joins_ctes.sql` | 25 |
| Task 18 | Multi-CTE - subject-level safety summary | `04_joins_ctes.sql` | 20 |
| Task 19 | ROW_NUMBER - number each subject's ALT results by visit date order | `05_window_functions.sql` | 30 |
| Task 20 | RANK vs DENSE_RANK - rank ALT values across the whole study | `05_window_functions.sql` | 30 |
| Task 21 | Highest ALT per subject (RANK + PARTITION BY, then filter) | `05_window_functions.sql` | 8 |
| Task 22 | Latest (last non-missing) result per subject per test - typical "last observation" logic | `05_window_functions.sql` | 100 |
| Task 23 | Change from baseline (screening) using FIRST_VALUE | `05_window_functions.sql` | 75 |
| Task 24 | Visit-to-visit ALT change using LAG | `05_window_functions.sql` | 76 |
| Task 25 | Running count of AEs per subject (cumulative) | `05_window_functions.sql` | 25 |
| Task 26 | Top 3 most frequent AE terms (DENSE_RANK on aggregated counts) | `05_window_functions.sql` | 4 |
| DQ-01 | Duplicate lab records (same subject + visit + test) | `06_data_quality_checks.sql` | 1 |
| DQ-01b | Identify which duplicate row to keep/query (window function) | `06_data_quality_checks.sql` | 2 |
| DQ-02 | Missing lab results | `06_data_quality_checks.sql` | 1 |
| DQ-03 | Missing vital sign values | `06_data_quality_checks.sql` | 3 |
| DQ-04 | Missing expected visits (subjects on study >= 84 days with no WEEK 12 lab) | `06_data_quality_checks.sql` | 0 |
| DQ-05 | Lab results out of normal range (see also view v_abnormal_labs) | `06_data_quality_checks.sql` | 8 |
| DQ-06 | Vital signs outside plausibility limits (hard range checks) | `06_data_quality_checks.sql` | 2 |
| DQ-07 | AE start date before first dose (pre-treatment event; confirm not mis-entered) | `06_data_quality_checks.sql` | 1 |
| DQ-08 | AE end date earlier than start date | `06_data_quality_checks.sql` | 1 |
| DQ-09 | AE missing causality | `06_data_quality_checks.sql` | 1 |
| DQ-10 | SAE not recovered but no end date AND outcome inconsistent | `06_data_quality_checks.sql` | 1 |
| DQ-11 | Con-med without indication | `06_data_quality_checks.sql` | 1 |
| DQ-12 | Con-med end date before start date | `06_data_quality_checks.sql` | 0 |
| DQ-13 | Missing demographics | `06_data_quality_checks.sql` | 1 |
| DQ-14 | Orphan records (child rows without a subject) - should return 0 rows | `06_data_quality_checks.sql` | 0 |
| DQ-15 | Assessments dated after last study date | `06_data_quality_checks.sql` | 0 |
| Task 27 | Query status summary | `07_query_log_workflow.sql` | 3 |
| Task 28 | Queries by domain and status | `07_query_log_workflow.sql` | 5 |
| Task 29 | Query turnaround time (days) for resolved/closed queries | `07_query_log_workflow.sql` | 3 |
| Task 30 | Average turnaround by domain | `07_query_log_workflow.sql` | 3 |
| Task 31 | Aging report - open/answered queries with age as of data cut-off | `07_query_log_workflow.sql` | 3 |
| Task 32 | Subjects with the most queries (RANK) | `07_query_log_workflow.sql` | 5 |
| Task 33 | Edit-check findings with NO query raised yet (con-meds missing indication) | `07_query_log_workflow.sql` | 1 |
| Task 34 | Full reconciliation listing | `08_sae_reconciliation.sql` | 5 |
| Task 35 | Reconciliation summary counts | `08_sae_reconciliation.sql` | 4 |

*A count of 0 on a DQ check means no issue was found in the sample data.*
