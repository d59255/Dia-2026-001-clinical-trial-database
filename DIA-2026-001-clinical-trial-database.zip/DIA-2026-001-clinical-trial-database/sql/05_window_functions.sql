-- =====================================================================
-- 05 | Window functions: RANK, DENSE_RANK, ROW_NUMBER, LAG, PARTITION BY
-- Practice table: LabResultsWF (ALT values)  |  Production table: LabResults
-- =====================================================================
USE dia_2026_001;

-- Task 19: ROW_NUMBER - number each subject's ALT results by visit date order
SELECT w.USUBJID, w.VISIT, w.ALT,
       ROW_NUMBER() OVER (PARTITION BY w.USUBJID ORDER BY w.WFID) AS rn
FROM LabResultsWF w;

-- Task 20: RANK vs DENSE_RANK - rank ALT values across the whole study
SELECT USUBJID, VISIT, ALT,
       RANK()       OVER (ORDER BY ALT DESC) AS rnk,
       DENSE_RANK() OVER (ORDER BY ALT DESC) AS dense_rnk
FROM LabResultsWF;

-- Task 21: Highest ALT per subject (RANK + PARTITION BY, then filter)
SELECT * FROM (
    SELECT USUBJID, VISIT, ALT,
           RANK() OVER (PARTITION BY USUBJID ORDER BY ALT DESC) AS rnk
    FROM LabResultsWF
) t
WHERE rnk = 1;

-- Task 22: Latest (last non-missing) result per subject per test - typical "last observation" logic
SELECT * FROM (
    SELECT l.USUBJID, l.LBTESTCD, l.VISIT, l.LBORRES, l.LBDTC,
           ROW_NUMBER() OVER (PARTITION BY l.USUBJID, l.LBTESTCD ORDER BY l.LBDTC DESC) AS rn
    FROM LabResults l
    WHERE l.LBORRES IS NOT NULL
) x
WHERE rn = 1;

-- Task 23: Change from baseline (screening) using FIRST_VALUE
SELECT USUBJID, VISIT, LBDTC, LBORRES,
       FIRST_VALUE(LBORRES) OVER (PARTITION BY USUBJID ORDER BY LBDTC) AS baseline,
       LBORRES - FIRST_VALUE(LBORRES) OVER (PARTITION BY USUBJID ORDER BY LBDTC) AS chg_from_bl
FROM LabResults
WHERE LBTESTCD = 'ALT' AND LBORRES IS NOT NULL;

-- Task 24: Visit-to-visit ALT change using LAG
SELECT USUBJID, VISIT, LBORRES AS alt,
       LAG(LBORRES) OVER (PARTITION BY USUBJID ORDER BY LBDTC) AS prev_alt,
       LBORRES - LAG(LBORRES) OVER (PARTITION BY USUBJID ORDER BY LBDTC) AS delta
FROM LabResults
WHERE LBTESTCD = 'ALT';

-- Task 25: Running count of AEs per subject (cumulative)
SELECT USUBJID, AEDECOD, AESTDTC,
       COUNT(*) OVER (PARTITION BY USUBJID ORDER BY AESTDTC, AESEQ) AS cumulative_ae
FROM AdverseEvents;

-- Task 26: Top 3 most frequent AE terms (DENSE_RANK on aggregated counts)
SELECT * FROM (
    SELECT AEDECOD, COUNT(*) AS n,
           DENSE_RANK() OVER (ORDER BY COUNT(*) DESC) AS drk
    FROM AdverseEvents
    GROUP BY AEDECOD
) t
WHERE drk <= 3;
