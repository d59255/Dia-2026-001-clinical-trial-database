-- =====================================================================
-- 08 | SAE reconciliation: EDC (AdverseEvents, AESER='Y') vs Safety DB
-- Outcome categories: MATCH | DISCREPANT | IN EDC ONLY | IN SAFETY DB ONLY
-- MySQL has no FULL OUTER JOIN -> emulate with LEFT JOIN UNION ALL anti-join
-- =====================================================================
USE dia_2026_001;

-- Task 34: Full reconciliation listing
SELECT e.USUBJID, e.AEDECOD AS edc_term, s.EVENT_TERM AS safety_term,
       e.AESTDTC AS edc_onset, s.ONSET_DATE AS safety_onset,
       e.AEREL AS edc_causality, s.CAUSALITY AS safety_causality,
       CASE WHEN s.CASEID IS NULL THEN 'IN EDC ONLY'
            WHEN e.AESTDTC <> s.ONSET_DATE THEN 'DISCREPANT - ONSET DATE'
            WHEN e.AEREL  <> s.CAUSALITY   THEN 'DISCREPANT - CAUSALITY'
            ELSE 'MATCH' END AS recon_status
FROM AdverseEvents e
LEFT JOIN SafetyDB_SAE s
       ON s.USUBJID = e.USUBJID AND s.EVENT_TERM = e.AEDECOD
WHERE e.AESER = 'Y'
UNION ALL
SELECT s.USUBJID, NULL, s.EVENT_TERM, NULL, s.ONSET_DATE, NULL, s.CAUSALITY, 'IN SAFETY DB ONLY'
FROM SafetyDB_SAE s
WHERE NOT EXISTS (SELECT 1 FROM AdverseEvents e
                  WHERE e.USUBJID = s.USUBJID AND e.AESER = 'Y' AND e.AEDECOD = s.EVENT_TERM);

-- Task 35: Reconciliation summary counts
WITH recon AS (
    SELECT CASE WHEN s.CASEID IS NULL THEN 'IN EDC ONLY'
                WHEN e.AESTDTC <> s.ONSET_DATE OR e.AEREL <> s.CAUSALITY THEN 'DISCREPANT'
                ELSE 'MATCH' END AS status
    FROM AdverseEvents e
    LEFT JOIN SafetyDB_SAE s ON s.USUBJID = e.USUBJID AND s.EVENT_TERM = e.AEDECOD
    WHERE e.AESER = 'Y'
    UNION ALL
    SELECT 'IN SAFETY DB ONLY'
    FROM SafetyDB_SAE s
    WHERE NOT EXISTS (SELECT 1 FROM AdverseEvents e
                      WHERE e.USUBJID = s.USUBJID AND e.AESER = 'Y' AND e.AEDECOD = s.EVENT_TERM)
)
SELECT status, COUNT(*) AS n FROM recon GROUP BY status;
