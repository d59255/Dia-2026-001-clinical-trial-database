-- =====================================================================
-- 06 | Data quality / edit checks  (each check = one potential query)
-- =====================================================================
USE dia_2026_001;

-- DQ-01 Duplicate lab records (same subject + visit + test)
SELECT USUBJID, VISIT, LBTESTCD, COUNT(*) AS n_records
FROM LabResults
GROUP BY USUBJID, VISIT, LBTESTCD
HAVING COUNT(*) > 1;

-- DQ-01b Identify which duplicate row to keep/query (window function)
SELECT * FROM (
    SELECT LBSEQ, USUBJID, VISIT, LBTESTCD, LBORRES,
           ROW_NUMBER() OVER (PARTITION BY USUBJID, VISIT, LBTESTCD ORDER BY LBSEQ) AS rn,
           COUNT(*)     OVER (PARTITION BY USUBJID, VISIT, LBTESTCD)                AS grp_n
    FROM LabResults
) t
WHERE grp_n > 1;

-- DQ-02 Missing lab results
SELECT LBSEQ, USUBJID, VISIT, LBTESTCD FROM LabResults WHERE LBORRES IS NULL;

-- DQ-03 Missing vital sign values
SELECT VSSEQ, USUBJID, VISIT, VSTESTCD FROM VitalSigns WHERE VSORRES IS NULL;

-- DQ-04 Missing expected visits (subjects on study >= 84 days with no WEEK 12 lab)
SELECT d.USUBJID
FROM Demographics d
WHERE DATEDIFF(d.RFENDTC, d.RFSTDTC) >= 84
  AND NOT EXISTS (SELECT 1 FROM LabResults l WHERE l.USUBJID = d.USUBJID AND l.VISIT = 'WEEK 12');

-- DQ-05 Lab results out of normal range (see also view v_abnormal_labs)
SELECT USUBJID, VISIT, LBTESTCD, LBORRES, LBSTNRLO, LBSTNRHI FROM LabResults
WHERE LBORRES < LBSTNRLO OR LBORRES > LBSTNRHI;

-- DQ-06 Vital signs outside plausibility limits (hard range checks)
SELECT VSSEQ, USUBJID, VISIT, VSTESTCD, VSORRES
FROM VitalSigns
WHERE (VSTESTCD = 'SYSBP' AND (VSORRES < 80  OR VSORRES > 180))
   OR (VSTESTCD = 'DIABP' AND (VSORRES < 40  OR VSORRES > 110))
   OR (VSTESTCD = 'PULSE' AND (VSORRES < 40  OR VSORRES > 120))
   OR (VSTESTCD = 'TEMP'  AND (VSORRES < 35  OR VSORRES > 39));

-- DQ-07 AE start date before first dose (pre-treatment event; confirm not mis-entered)
SELECT a.AESEQ, a.USUBJID, a.AEDECOD, a.AESTDTC, d.RFSTDTC
FROM AdverseEvents a JOIN Demographics d ON d.USUBJID = a.USUBJID
WHERE a.AESTDTC < d.RFSTDTC;

-- DQ-08 AE end date earlier than start date
SELECT AESEQ, USUBJID, AEDECOD, AESTDTC, AEENDTC FROM AdverseEvents WHERE AEENDTC < AESTDTC;

-- DQ-09 AE missing causality
SELECT AESEQ, USUBJID, AEDECOD FROM AdverseEvents WHERE AEREL IS NULL;

-- DQ-10 SAE not recovered but no end date AND outcome inconsistent
SELECT AESEQ, USUBJID, AEDECOD, AEENDTC, AEOUT FROM AdverseEvents
WHERE AESER = 'Y' AND AEENDTC IS NULL;

-- DQ-11 Con-med without indication
SELECT CMSEQ, USUBJID, CMTRT FROM ConcomitantMeds WHERE CMINDC IS NULL;

-- DQ-12 Con-med end date before start date
SELECT CMSEQ, USUBJID, CMTRT, CMSTDTC, CMENDTC FROM ConcomitantMeds WHERE CMENDTC < CMSTDTC;

-- DQ-13 Missing demographics
SELECT USUBJID, 'AGE' AS missing_field FROM Demographics WHERE AGE IS NULL
UNION ALL
SELECT USUBJID, 'RACE' FROM Demographics WHERE RACE IS NULL;

-- DQ-14 Orphan records (child rows without a subject) - should return 0 rows
SELECT 'AE' AS dom, a.USUBJID FROM AdverseEvents a LEFT JOIN Demographics d ON d.USUBJID = a.USUBJID WHERE d.USUBJID IS NULL
UNION ALL
SELECT 'LB', l.USUBJID FROM LabResults l LEFT JOIN Demographics d ON d.USUBJID = l.USUBJID WHERE d.USUBJID IS NULL;

-- DQ-15 Assessments dated after last study date
SELECT l.USUBJID, l.VISIT, l.LBDTC, d.RFENDTC
FROM LabResults l JOIN Demographics d ON d.USUBJID = l.USUBJID
WHERE l.LBDTC > d.RFENDTC;
