-- =====================================================================
-- 07 | Query Log: raise -> answer -> resolve -> close, plus metrics
-- Lifecycle:  OPEN -> ANSWERED (site responds) -> RESOLVED (DM accepts) -> CLOSED
-- =====================================================================
USE dia_2026_001;

-- Raise a new query for an out-of-range vital sign
INSERT INTO QueryLog (QUERYID, USUBJID, DOMAIN, FIELD, QUERYTEXT, RAISEDDT, RAISEDBY, STATUS)
SELECT 6, USUBJID, 'VS', 'VSORRES',
       CONCAT('Systolic BP ', VSORRES, ' mmHg at ', VISIT, ' is outside expected range. Please verify.'),
       '2026-04-02', 'DM-Deepak', 'OPEN'
FROM VitalSigns
WHERE VSTESTCD = 'SYSBP' AND VSORRES > 180;

-- Site answers
UPDATE QueryLog SET STATUS = 'ANSWERED' WHERE QUERYID = 3;

-- Data manager resolves after verifying the corrected data
UPDATE QueryLog
SET STATUS = 'RESOLVED', RESOLVEDDT = '2026-04-05', RESOLUTION = 'Site provided age from source document.'
WHERE QUERYID = 3;

-- Task 27: Query status summary
SELECT STATUS, COUNT(*) AS n FROM QueryLog GROUP BY STATUS;

-- Task 28: Queries by domain and status
SELECT DOMAIN, STATUS, COUNT(*) AS n FROM QueryLog GROUP BY DOMAIN, STATUS ORDER BY DOMAIN;

-- Task 29: Query turnaround time (days) for resolved/closed queries
SELECT QUERYID, DOMAIN, RAISEDDT, RESOLVEDDT, DATEDIFF(RESOLVEDDT, RAISEDDT) AS tat_days
FROM QueryLog
WHERE RESOLVEDDT IS NOT NULL;

-- Task 30: Average turnaround by domain
SELECT DOMAIN, ROUND(AVG(DATEDIFF(RESOLVEDDT, RAISEDDT)),1) AS avg_tat_days, COUNT(*) AS n
FROM QueryLog WHERE RESOLVEDDT IS NOT NULL GROUP BY DOMAIN;

-- Task 31: Aging report - open/answered queries with age as of data cut-off
SELECT QUERYID, USUBJID, DOMAIN, STATUS, RAISEDDT,
       DATEDIFF('2026-04-30', RAISEDDT) AS age_days,
       CASE WHEN DATEDIFF('2026-04-30', RAISEDDT) > 30 THEN '>30 days'
            WHEN DATEDIFF('2026-04-30', RAISEDDT) > 14 THEN '15-30 days'
            ELSE '<=14 days' END AS aging_bucket
FROM QueryLog
WHERE STATUS IN ('OPEN','ANSWERED')
ORDER BY age_days DESC;

-- Task 32: Subjects with the most queries (RANK)
SELECT USUBJID, COUNT(*) AS n_queries,
       RANK() OVER (ORDER BY COUNT(*) DESC) AS rnk
FROM QueryLog
GROUP BY USUBJID;

-- Task 33: Edit-check findings with NO query raised yet (con-meds missing indication)
SELECT c.CMSEQ, c.USUBJID, c.CMTRT
FROM ConcomitantMeds c
WHERE c.CMINDC IS NULL
  AND NOT EXISTS (SELECT 1 FROM QueryLog q
                  WHERE q.USUBJID = c.USUBJID AND q.DOMAIN = 'CM');
