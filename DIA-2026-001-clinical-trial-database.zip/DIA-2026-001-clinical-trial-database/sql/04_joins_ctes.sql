-- =====================================================================
-- 04 | JOINs, subqueries, CTEs, views
-- =====================================================================
USE dia_2026_001;

-- Task 11: AEs with subject demographics (INNER JOIN)
SELECT a.USUBJID, d.ARM, d.AGE, d.SEX, a.AEDECOD, a.AESEV, a.AESTDTC
FROM AdverseEvents a
JOIN Demographics d ON d.USUBJID = a.USUBJID
ORDER BY a.USUBJID, a.AESTDTC;

-- Task 12: Subjects with NO adverse events (LEFT JOIN / anti-join)
SELECT d.USUBJID, d.ARM
FROM Demographics d
LEFT JOIN AdverseEvents a ON a.USUBJID = d.USUBJID
WHERE a.USUBJID IS NULL;

-- Task 13: AE incidence by arm (subjects with >=1 AE / subjects in arm)
SELECT d.ARM,
       COUNT(DISTINCT d.USUBJID)                                   AS n_subjects,
       COUNT(DISTINCT a.USUBJID)                                   AS n_with_ae,
       ROUND(100 * COUNT(DISTINCT a.USUBJID) / COUNT(DISTINCT d.USUBJID), 1) AS pct_with_ae
FROM Demographics d
LEFT JOIN AdverseEvents a ON a.USUBJID = d.USUBJID
GROUP BY d.ARM;

-- Task 14: Out-of-range labs with subject context
SELECT l.USUBJID, d.ARM, l.VISIT, l.LBTESTCD, l.LBORRES, l.LBSTNRLO, l.LBSTNRHI
FROM LabResults l
JOIN Demographics d ON d.USUBJID = l.USUBJID
WHERE l.LBORRES < l.LBSTNRLO OR l.LBORRES > l.LBSTNRHI
ORDER BY l.USUBJID, l.VISIT;

-- Task 15: Subquery - subjects whose max ALT is above the study average ALT
SELECT USUBJID, MAX(LBORRES) AS max_alt
FROM LabResults
WHERE LBTESTCD = 'ALT'
GROUP BY USUBJID
HAVING MAX(LBORRES) > (SELECT AVG(LBORRES) FROM LabResults WHERE LBTESTCD = 'ALT');

-- Task 16: Con-med taken for an AE (indication matches AE term) - self join logic
SELECT c.USUBJID, c.CMTRT, c.CMINDC, a.AEDECOD, a.AESTDTC, c.CMSTDTC
FROM ConcomitantMeds c
JOIN AdverseEvents a
  ON a.USUBJID = c.USUBJID
 AND UPPER(a.AEDECOD) LIKE CONCAT('%', UPPER(c.CMINDC), '%');
-- NOTE: loose text match for demonstration; real CDM work links via AE number (CMAENO).

-- Task 17: CTE - first-dose-relative study day of each AE
WITH ae_day AS (
    SELECT a.AESEQ, a.USUBJID, a.AEDECOD, a.AESTDTC,
           DATEDIFF(a.AESTDTC, d.RFSTDTC) + 1 AS aestdy
    FROM AdverseEvents a
    JOIN Demographics d ON d.USUBJID = a.USUBJID
)
SELECT * FROM ae_day ORDER BY aestdy;

-- Task 18: Multi-CTE - subject-level safety summary
WITH ae_cnt AS (
    SELECT USUBJID, COUNT(*) AS n_ae, SUM(AESER = 'Y') AS n_sae FROM AdverseEvents GROUP BY USUBJID
), lab_cnt AS (
    SELECT USUBJID, SUM(LBORRES > LBSTNRHI OR LBORRES < LBSTNRLO) AS n_abn_lab FROM LabResults GROUP BY USUBJID
)
SELECT d.USUBJID, d.ARM,
       IFNULL(a.n_ae,0) AS n_ae, IFNULL(a.n_sae,0) AS n_sae, IFNULL(l.n_abn_lab,0) AS n_abn_lab
FROM Demographics d
LEFT JOIN ae_cnt  a ON a.USUBJID = d.USUBJID
LEFT JOIN lab_cnt l ON l.USUBJID = d.USUBJID
ORDER BY n_sae DESC, n_ae DESC;

-- View: reusable out-of-range lab listing
DROP VIEW IF EXISTS v_abnormal_labs;
CREATE VIEW v_abnormal_labs AS
SELECT l.LBSEQ, l.USUBJID, l.VISIT, l.LBTESTCD, l.LBORRES, l.LBSTNRLO, l.LBSTNRHI,
       CASE WHEN l.LBORRES > l.LBSTNRHI THEN 'HIGH' ELSE 'LOW' END AS direction
FROM LabResults l
WHERE l.LBORRES > l.LBSTNRHI OR l.LBORRES < l.LBSTNRLO;

SELECT * FROM v_abnormal_labs;
