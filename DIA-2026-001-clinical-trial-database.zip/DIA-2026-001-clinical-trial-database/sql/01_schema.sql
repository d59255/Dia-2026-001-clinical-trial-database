-- =====================================================================
-- DIA-2026-001 | Simulated Clinical Trial Database (MySQL 8.0+)
-- Tables are modelled on SDTM domains: DM, AE, LB, VS, CM
-- All data is SYNTHETIC. No real patient information.
-- =====================================================================
DROP DATABASE IF EXISTS dia_2026_001;
CREATE DATABASE dia_2026_001;
USE dia_2026_001;

-- DM : Demographics ---------------------------------------------------
CREATE TABLE Demographics (
    USUBJID  VARCHAR(20)  NOT NULL PRIMARY KEY,
    STUDYID  VARCHAR(15)  NOT NULL,
    SITEID   VARCHAR(5)   NOT NULL,
    SUBJID   VARCHAR(5)   NOT NULL,
    AGE      INT          NULL,
    SEX      CHAR(1)      NOT NULL,
    RACE     VARCHAR(40),
    ARM      VARCHAR(20)  NOT NULL,
    COUNTRY  CHAR(3),
    RFSTDTC  DATE         NOT NULL,   -- first study treatment date
    RFENDTC  DATE         NULL,       -- last study date
    CONSTRAINT chk_sex CHECK (SEX IN ('M','F')),
    CONSTRAINT chk_age CHECK (AGE IS NULL OR AGE BETWEEN 18 AND 90)
);

-- AE : Adverse Events -------------------------------------------------
CREATE TABLE AdverseEvents (
    AESEQ    INT          NOT NULL PRIMARY KEY,
    USUBJID  VARCHAR(20)  NOT NULL,
    AETERM   VARCHAR(60)  NOT NULL,   -- verbatim term
    AEDECOD  VARCHAR(60),             -- dictionary-coded term (MedDRA PT)
    AESEV    VARCHAR(10)  NOT NULL,
    AESER    CHAR(1)      NOT NULL,   -- serious Y/N
    AEREL    VARCHAR(25),             -- causality
    AESTDTC  DATE         NOT NULL,
    AEENDTC  DATE         NULL,
    AEOUT    VARCHAR(40),
    AEACN    VARCHAR(30),
    CONSTRAINT fk_ae_dm  FOREIGN KEY (USUBJID) REFERENCES Demographics(USUBJID),
    CONSTRAINT chk_aesev CHECK (AESEV IN ('MILD','MODERATE','SEVERE')),
    CONSTRAINT chk_aeser CHECK (AESER IN ('Y','N'))
);

-- LB : Laboratory Results ---------------------------------------------
CREATE TABLE LabResults (
    LBSEQ     INT           NOT NULL PRIMARY KEY,
    USUBJID   VARCHAR(20)   NOT NULL,
    VISIT     VARCHAR(15)   NOT NULL,
    LBTESTCD  VARCHAR(8)    NOT NULL,
    LBTEST    VARCHAR(40)   NOT NULL,
    LBORRES   DECIMAL(8,2)  NULL,
    LBORRESU  VARCHAR(10),
    LBSTNRLO  DECIMAL(8,2),           -- normal range low
    LBSTNRHI  DECIMAL(8,2),           -- normal range high
    LBDTC     DATE,
    CONSTRAINT fk_lb_dm FOREIGN KEY (USUBJID) REFERENCES Demographics(USUBJID)
);

-- VS : Vital Signs ----------------------------------------------------
CREATE TABLE VitalSigns (
    VSSEQ     INT           NOT NULL PRIMARY KEY,
    USUBJID   VARCHAR(20)   NOT NULL,
    VISIT     VARCHAR(15)   NOT NULL,
    VSTESTCD  VARCHAR(8)    NOT NULL,
    VSORRES   DECIMAL(6,1)  NULL,
    VSORRESU  VARCHAR(10),
    VSDTC     DATE,
    CONSTRAINT fk_vs_dm FOREIGN KEY (USUBJID) REFERENCES Demographics(USUBJID)
);

-- CM : Concomitant Medications ----------------------------------------
CREATE TABLE ConcomitantMeds (
    CMSEQ    INT          NOT NULL PRIMARY KEY,
    USUBJID  VARCHAR(20)  NOT NULL,
    CMTRT    VARCHAR(40)  NOT NULL,
    CMDOSE   DECIMAL(8,2),
    CMDOSU   VARCHAR(10),
    CMSTDTC  DATE,
    CMENDTC  DATE         NULL,
    CMINDC   VARCHAR(40)  NULL,
    CONSTRAINT fk_cm_dm FOREIGN KEY (USUBJID) REFERENCES Demographics(USUBJID)
);

-- Query Log (data cleaning workflow) ----------------------------------
CREATE TABLE QueryLog (
    QUERYID    INT          NOT NULL PRIMARY KEY,
    USUBJID    VARCHAR(20)  NOT NULL,
    DOMAIN     VARCHAR(4)   NOT NULL,
    FIELD      VARCHAR(15)  NOT NULL,
    QUERYTEXT  VARCHAR(255) NOT NULL,
    RAISEDDT   DATE         NOT NULL,
    RAISEDBY   VARCHAR(30),
    STATUS     VARCHAR(10)  NOT NULL,   -- OPEN / ANSWERED / RESOLVED / CLOSED
    RESOLVEDDT DATE         NULL,
    RESOLUTION VARCHAR(255) NULL,
    CONSTRAINT fk_ql_dm FOREIGN KEY (USUBJID) REFERENCES Demographics(USUBJID),
    CONSTRAINT chk_status CHECK (STATUS IN ('OPEN','ANSWERED','RESOLVED','CLOSED'))
);

-- Safety database extract (external system, for SAE reconciliation) ---
CREATE TABLE SafetyDB_SAE (
    CASEID      VARCHAR(12)  NOT NULL PRIMARY KEY,
    USUBJID     VARCHAR(20)  NOT NULL,
    EVENT_TERM  VARCHAR(60),
    ONSET_DATE  DATE,
    CAUSALITY   VARCHAR(25),
    OUTCOME     VARCHAR(40)
);

-- Practice table for window functions ---------------------------------
CREATE TABLE LabResultsWF (
    WFID     INT NOT NULL PRIMARY KEY,
    USUBJID  VARCHAR(20) NOT NULL,
    VISIT    VARCHAR(15) NOT NULL,
    ALT      DECIMAL(8,2)
);

CREATE INDEX idx_ae_subj ON AdverseEvents(USUBJID);
CREATE INDEX idx_lb_subj ON LabResults(USUBJID, VISIT, LBTESTCD);
CREATE INDEX idx_vs_subj ON VitalSigns(USUBJID, VISIT);
