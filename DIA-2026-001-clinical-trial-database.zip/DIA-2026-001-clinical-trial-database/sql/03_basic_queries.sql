-- =====================================================================
-- 03 | Basic queries: SELECT, WHERE, GROUP BY, HAVING, CASE, UNION
-- =====================================================================
USE dia_2026_001;

-- Task 1: Enrolment by arm and site
SELECT SITEID, ARM, COUNT(*) AS subjects
FROM Demographics
GROUP BY SITEID, ARM
ORDER BY SITEID, ARM;

-- Task 2: Age summary by arm (NULL ages ignored by aggregates)
SELECT ARM, COUNT(AGE) AS n_age, MIN(AGE) AS min_age, MAX(AGE) AS max_age, ROUND(AVG(AGE),1) AS mean_age
FROM Demographics
GROUP BY ARM;

-- Task 3: Subjects with missing age
SELECT USUBJID, SITEID FROM Demographics WHERE AGE IS NULL;

-- Task 4: Early discontinuations (< 84 days on study)
SELECT USUBJID, ARM, RFSTDTC, RFENDTC, DATEDIFF(RFENDTC, RFSTDTC) AS days_on_study
FROM Demographics
WHERE DATEDIFF(RFENDTC, RFSTDTC) < 84;

-- Task 5: AE count per subject, only subjects with 2+ AEs (HAVING)
SELECT USUBJID, COUNT(*) AS ae_count
FROM AdverseEvents
GROUP BY USUBJID
HAVING COUNT(*) >= 2;

-- Task 6: AE severity distribution
SELECT AESEV, COUNT(*) AS n FROM AdverseEvents GROUP BY AESEV;

-- Task 7: All serious AEs (SAEs)
SELECT AESEQ, USUBJID, AEDECOD, AESEV, AEREL, AESTDTC, AEOUT, AEACN
FROM AdverseEvents
WHERE AESER = 'Y'
ORDER BY AESTDTC;

-- Task 8: Classify lab results with CASE WHEN
SELECT LBSEQ, USUBJID, VISIT, LBTESTCD, LBORRES, LBSTNRLO, LBSTNRHI,
       CASE WHEN LBORRES IS NULL        THEN 'MISSING'
            WHEN LBORRES < LBSTNRLO     THEN 'LOW'
            WHEN LBORRES > LBSTNRHI     THEN 'HIGH'
            ELSE 'NORMAL' END AS lab_flag
FROM LabResults;

-- Task 9: Lab flag summary per test
SELECT LBTESTCD,
       SUM(LBORRES IS NULL) AS missing,
       SUM(LBORRES < LBSTNRLO) AS low,
       SUM(LBORRES > LBSTNRHI) AS high,
       COUNT(*) AS total
FROM LabResults
GROUP BY LBTESTCD;

-- Task 10: UNION - subjects who had an SAE OR a lab value above 2x ULN
SELECT USUBJID, 'SAE' AS reason FROM AdverseEvents WHERE AESER = 'Y'
UNION
SELECT USUBJID, 'LAB >2xULN' FROM LabResults WHERE LBORRES > 2 * LBSTNRHI
ORDER BY USUBJID;
