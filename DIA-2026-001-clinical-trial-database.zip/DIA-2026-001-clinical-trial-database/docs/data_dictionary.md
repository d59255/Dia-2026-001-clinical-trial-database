# Data Dictionary

SDTM-style variable names. Tables are simplified for learning.

## Demographics (DM)
| Variable | Type | Description |
|---|---|---|
| USUBJID | VARCHAR(20) PK | Unique subject ID: STUDYID-SITEID-SUBJID |
| STUDYID, SITEID, SUBJID | VARCHAR | Study, site and subject identifiers |
| AGE | INT | Age in years (18-90 constraint) |
| SEX | CHAR(1) | M / F |
| RACE | VARCHAR | Race |
| ARM | VARCHAR | Planned treatment arm |
| COUNTRY | CHAR(3) | ISO country code |
| RFSTDTC / RFENDTC | DATE | First treatment date / last study date |

## AdverseEvents (AE)
| Variable | Description |
|---|---|
| AESEQ (PK) | Sequence number |
| AETERM / AEDECOD | Verbatim term / coded preferred term |
| AESEV | MILD, MODERATE, SEVERE |
| AESER | Serious flag Y/N |
| AEREL | Causality (RELATED, POSSIBLY RELATED, UNLIKELY RELATED, NOT RELATED) |
| AESTDTC / AEENDTC | Start / end date |
| AEOUT | Outcome |
| AEACN | Action taken with study drug |

## LabResults (LB)
| Variable | Description |
|---|---|
| LBSEQ (PK) | Sequence number |
| VISIT | SCREENING, WEEK 4, WEEK 8, WEEK 12 |
| LBTESTCD / LBTEST | Test code / name (ALT, AST, CREAT, HGB, GLUC) |
| LBORRES, LBORRESU | Original result and unit |
| LBSTNRLO / LBSTNRHI | Normal range low / high |
| LBDTC | Collection date |

## VitalSigns (VS)
| Variable | Description |
|---|---|
| VSSEQ (PK) | Sequence number |
| VISIT | Visit name |
| VSTESTCD | SYSBP, DIABP, PULSE, TEMP |
| VSORRES, VSORRESU | Result and unit |
| VSDTC | Date of measurement |

## ConcomitantMeds (CM)
| Variable | Description |
|---|---|
| CMSEQ (PK) | Sequence number |
| CMTRT | Medication name |
| CMDOSE, CMDOSU | Dose and unit |
| CMSTDTC / CMENDTC | Start / end date (NULL end = ongoing) |
| CMINDC | Indication |

## QueryLog
| Variable | Description |
|---|---|
| QUERYID (PK) | Query number |
| USUBJID, DOMAIN, FIELD | Where the discrepancy is |
| QUERYTEXT | Text sent to the site |
| RAISEDDT, RAISEDBY | Date raised, raised by |
| STATUS | OPEN, ANSWERED, RESOLVED, CLOSED |
| RESOLVEDDT, RESOLUTION | Resolution date and description |

## SafetyDB_SAE
External safety database extract used only for SAE reconciliation: CASEID, USUBJID, EVENT_TERM, ONSET_DATE, CAUSALITY, OUTCOME.

## LabResultsWF
Small practice table (WFID, USUBJID, VISIT, ALT) for window-function exercises.
