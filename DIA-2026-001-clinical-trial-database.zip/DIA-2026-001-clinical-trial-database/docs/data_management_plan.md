# Data Management Plan (DMP)

**Study:** DIA-2026-001 (simulated) | **Version:** 1.0 | **Phase:** II | **Design:** randomised, placebo-controlled, 12 weeks

## 1. Purpose and scope
Defines how clinical data for DIA-2026-001 are collected, cleaned, reconciled and locked. Applies to domains DM, AE, LB, VS, CM and the Query Log.

## 2. Roles
| Role | Responsibility |
|---|---|
| Data Manager | DMP, edit checks, query management, reconciliation, lock |
| Clinical Data Associate | Data review, query raising, listings |
| Programmer / Biostatistics | SDTM mapping, TLFs |
| Site | Data entry, query response |
| Safety / PV | SAE case processing and reconciliation |

## 3. Data flow
Site source documents -> EDC entry -> automated edit checks -> manual review -> queries -> site response -> data correction -> reconciliation -> database lock -> export (SDTM).

## 4. Data collection
- 20 subjects, 2 sites, visits: Screening, Week 4, Week 8, Week 12.
- CRF modules: Demographics, AE, Labs, Vitals, Con-meds.

## 5. Data validation (edit checks)
Full list in `sql/06_data_quality_checks.sql`.
| ID | Check | Type |
|---|---|---|
| DQ-01 | Duplicate lab record | Consistency |
| DQ-02/03 | Missing lab / vital value | Completeness |
| DQ-05 | Lab outside normal range | Range |
| DQ-06 | Vital outside plausibility limits | Range |
| DQ-07 | AE before first dose | Date logic |
| DQ-08 | AE end before start | Date logic |
| DQ-09 | AE causality missing | Completeness |
| DQ-11 | Con-med indication missing | Completeness |

## 6. Query management
Lifecycle OPEN -> ANSWERED -> RESOLVED -> CLOSED. Target turnaround: 5 working days. See `query_log_process.md`.

## 7. Coding
- Adverse events coded to MedDRA preferred terms.
- Concomitant medications coded to WHODrug.

## 8. External data and reconciliation
- SAE reconciliation EDC vs safety database (see `sae_reconciliation.md`): at each interim cut and before lock.
- Lab normal ranges reconciled with the central lab reference file.

## 9. Database lock
Criteria: all queries closed, SAE reconciliation signed off, coding complete, all edit checks clean, protocol deviations reviewed, QC on key variables done. Lock approved by Data Manager, Biostatistics and Clinical Lead.

## 10. Archiving
Final database, DMP, query log and reconciliation reports archived in the TMF.

## Revision history
| Version | Date | Change |
|---|---|---|
| 1.0 | 2026 | Initial version |
