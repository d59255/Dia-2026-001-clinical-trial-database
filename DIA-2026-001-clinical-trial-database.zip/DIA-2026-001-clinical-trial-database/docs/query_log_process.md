# Query Management Process

## Lifecycle
```
Edit check / manual review finds discrepancy
        |
   OPEN  (query raised to site)
        |
 ANSWERED (site responds in EDC)
        |
 RESOLVED (data manager verifies; data corrected or confirmed)
        |
  CLOSED  (final, after review / database lock reconciliation)
```

## Good query text
- Specific: state the value, the visit and the reason it is questioned.
- Neutral and non-leading: never suggest the "right" answer.
- Example: *"ALT 142 U/L at Week 8 exceeds ULN (56). Please confirm the value and clinical significance."*

## Metrics tracked (see `sql/07_query_log_workflow.sql`)
- Queries by status and domain
- Average turnaround time (raised to resolved)
- Aging buckets (<=14, 15-30, >30 days) for open queries
- Subjects with the highest query burden
- Edit-check findings with no query raised yet
