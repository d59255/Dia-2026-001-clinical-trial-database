# SAE Reconciliation (EDC vs Safety Database)

**Purpose:** ensure every serious adverse event reported in the clinical database (EDC) matches the corresponding case in the safety (pharmacovigilance) database. Done periodically and before database lock.

## Fields compared
| Field | EDC | Safety DB |
|---|---|---|
| Subject | USUBJID | USUBJID |
| Event term | AEDECOD | EVENT_TERM |
| Onset date | AESTDTC | ONSET_DATE |
| Causality | AEREL | CAUSALITY |
| Outcome | AEOUT | OUTCOME |

## Outcome categories
| Status | Meaning | Action |
|---|---|---|
| MATCH | All compared fields agree | None |
| DISCREPANT | Same event, different date / causality / outcome | Query site or safety team; correct the wrong system |
| IN EDC ONLY | SAE in EDC, no safety case | Confirm with site whether SAE form was submitted; notify safety |
| IN SAFETY DB ONLY | Safety case with no EDC record | Query site to enter AE in EDC |

## Result on this dataset (Task 34 / 35)
| Subject | Finding | Status |
|---|---|---|
| 101-003 Pneumonia | All fields agree | MATCH |
| 101-007 Chest pain | Onset 21-Feb (EDC) vs 22-Feb (safety) | DISCREPANT |
| 101-010 Hypotension | RELATED (EDC) vs POSSIBLY RELATED (safety) | DISCREPANT |
| 102-015 Pneumonia | No safety case | IN EDC ONLY |
| 102-019 Syncope | Not entered in EDC | IN SAFETY DB ONLY |

Summary: 1 match, 2 discrepant, 1 EDC only, 1 safety DB only. Each non-match becomes a query or a safety-team action item.

## Sign-off structure
| Item | Owner | Date |
|---|---|---|
| Reconciliation run | Data Manager | |
| Discrepancies sent | Data Manager | |
| Safety response received | Safety/PV | |
| Final reconciliation signed | DM + PV lead | |
